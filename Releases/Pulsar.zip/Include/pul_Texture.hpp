#pragma once

#include <iostream>
#include <string>
#include <string_view>

#include <EquinoxSTD.hpp>
#include <SDL.h>
#include <SDL_image.h>

namespace pul
{
	class Texture
	{
	public:
		struct Color
		{
			std::uint8_t r, g, b, a;
		};

		struct Config
		{
			eqx::Rectangle<double> destination;
			double angle;
			eqx::Point<double> rotationPoint;
			SDL_RendererFlip flip;
			Color rgba;
		};

		explicit constexpr inline Texture() noexcept;
		explicit inline Texture(SDL_Renderer* renderer, 
			std::string_view filePath);

		inline Texture(const Texture& other);
		inline Texture(Texture&& other);
		inline Texture& operator= (const Texture& other);
		inline Texture& operator= (Texture&& other);

		inline ~Texture() noexcept;

		inline void setRenderer(SDL_Renderer* renderer) noexcept;
		inline void loadFile(std::string_view filePath);

		inline void render(const eqx::Point<double>& location) const;
		inline void
			render(const eqx::Rectangle<double>& destination) const;
		inline void render(const Config& config) const;

	private:
		int m_Width, m_Height;

		std::string m_FilePath;

		SDL_Texture* m_SdlTexture;
		SDL_Renderer* m_Renderer;
	};
}

#include "pul_DefHeaders/pul_TextureDef.hpp"